# Video Enhancer AI (Android, offline)

Upscale video (AI via ONNX Runtime: NNAPI GPU/NPU -> XNNPACK -> CPU) + interpolasi FPS (60/90/120, motion-compensated multi-core).

## Build di GitHub
1. Ekstrak ZIP, upload SEMUA isinya (termasuk folder `.github`) ke repo baru.
2. Tab **Actions** -> workflow "Build APK" jalan otomatis (atau Run workflow).
3. Selesai -> download artifact **VideoEnhancer-APK** -> install APK.

## Model AI
Aplikasi butuh model ONNX super-resolution (input NCHW float32 RGB 0..1, output 3 channel, mis. Real-ESRGAN general x4v3 / compact).
- Opsi A: impor lewat tombol "Impor model .onnx" di app.
- Opsi B: taruh file di `app/src/main/assets/models/sr.onnx` sebelum upload ke GitHub.
Tanpa model, app memakai fallback Bicubic + Sharpen.
