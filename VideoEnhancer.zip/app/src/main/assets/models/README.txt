Taruh model ONNX di sini dengan nama sr.onnx (opsional)
