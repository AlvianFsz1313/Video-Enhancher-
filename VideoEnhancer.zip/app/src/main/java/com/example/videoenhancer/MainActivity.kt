package com.example.videoenhancer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {
    private var videoUri: Uri? = null
    private lateinit var tvVideo: TextView
    private lateinit var tvModel: TextView
    private lateinit var tvStatus: TextView
    private lateinit var bar: ProgressBar
    private lateinit var btnStart: Button
    private lateinit var btnCancel: Button
    private lateinit var cbSharp: CheckBox
    private lateinit var scaleBtns: List<RadioButton>
    private lateinit var fpsBtns: List<RadioButton>
    private val scaleVals = listOf(1, 2, 4)
    private val fpsVals = listOf(60, 90, 120)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(root: LinearLayout, t: String) {
        root.addView(TextView(this).apply { text = t; textSize = 15f; setPadding(0, dp(18), 0, dp(4)) })
    }

    private fun radios(root: LinearLayout, labels: List<String>, def: Int): List<RadioButton> {
        val g = RadioGroup(this); g.orientation = RadioGroup.HORIZONTAL
        val list = labels.map { l -> RadioButton(this).apply { text = l; id = View.generateViewId() } }
        list.forEach { g.addView(it) }
        g.check(list[def].id)
        root.addView(g)
        return list
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(32), dp(20), dp(24)) }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(TextView(this).apply { text = "Video Enhancer AI"; textSize = 26f })
        root.addView(TextView(this).apply { text = "Upscale + interpolasi FPS, 100% offline"; textSize = 13f })

        label(root, "1. Video")
        root.addView(Button(this).apply { text = "Pilih video"; setOnClickListener { pick(1, "video/*") } })
        tvVideo = TextView(this).apply { text = "Belum ada video" }; root.addView(tvVideo)

        label(root, "2. Model AI (ONNX, mis. Real-ESRGAN)")
        root.addView(Button(this).apply { text = "Impor model .onnx"; setOnClickListener { pick(2, "*/*") } })
        tvModel = TextView(this); root.addView(tvModel); refreshModel()

        label(root, "3. Skala resolusi")
        scaleBtns = radios(root, listOf("1x", "2x", "4x"), 1)
        label(root, "4. Target FPS")
        fpsBtns = radios(root, listOf("60", "90", "120"), 1)
        cbSharp = CheckBox(this).apply { text = "Pertajam detail (sharpen ringan)"; isChecked = true }
        root.addView(cbSharp)

        btnStart = Button(this).apply { text = "MULAI PROSES"; isEnabled = false; setOnClickListener { start() } }
        btnCancel = Button(this).apply { text = "Batalkan"; isEnabled = false; setOnClickListener { cancelWork() } }
        root.addView(btnStart); root.addView(btnCancel)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(bar)
        tvStatus = TextView(this).apply { setPadding(0, dp(8), 0, 0) }; root.addView(tvStatus)

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
    }

    override fun onResume() {
        super.onResume()
        ProgressHub.listener = { p, m, done -> runOnUiThread { show(p, m, done) } }
        show(ProgressHub.lastPct, ProgressHub.lastMsg, !ProgressHub.running)
    }

    override fun onPause() { super.onPause(); ProgressHub.listener = null }

    private fun show(p: Float, m: String, done: Boolean) {
        bar.progress = (p * 100).toInt()
        tvStatus.text = m
        btnStart.isEnabled = done && videoUri != null
        btnCancel.isEnabled = !done
    }

    private fun pick(code: Int, type: String) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); this.type = type
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, code)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (resultCode != RESULT_OK) return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        if (requestCode == 1) {
            videoUri = uri
            tvVideo.text = uri.lastPathSegment ?: uri.toString()
            btnStart.isEnabled = !ProgressHub.running
        } else if (requestCode == 2) {
            tvModel.text = "Menyalin model..."
            Thread {
                try {
                    contentResolver.openInputStream(uri)!!.use { i -> File(filesDir, "sr.onnx").outputStream().use { i.copyTo(it) } }
                } catch (e: Exception) { runOnUiThread { tvModel.text = "Gagal impor: ${e.message}" }; return@Thread }
                runOnUiThread { refreshModel() }
            }.start()
        }
    }

    private fun refreshModel() {
        val f = File(filesDir, "sr.onnx")
        val inAssets = assets.list("models")?.contains("sr.onnx") == true
        tvModel.text = when {
            f.exists() -> "Model terimpor: sr.onnx (${f.length() / 1024 / 1024} MB)"
            inAssets -> "Model bawaan APK: sr.onnx"
            else -> "Belum ada model -> fallback Bicubic + Sharpen"
        }
    }

    private fun start() {
        val uri = videoUri ?: return
        val scale = scaleVals[scaleBtns.indexOfFirst { it.isChecked }]
        val fps = fpsVals[fpsBtns.indexOfFirst { it.isChecked }]
        val i = Intent(this, EnhanceService::class.java).apply {
            putExtra("uri", uri.toString()); putExtra("scale", scale); putExtra("fps", fps)
            putExtra("sharpen", cbSharp.isChecked)
            data = uri; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ProgressHub.update(0f, "Memulai...")
        startForegroundService(i)
        btnStart.isEnabled = false; btnCancel.isEnabled = true
    }

    private fun cancelWork() {
        startService(Intent(this, EnhanceService::class.java).setAction(EnhanceService.ACTION_CANCEL))
    }
}
