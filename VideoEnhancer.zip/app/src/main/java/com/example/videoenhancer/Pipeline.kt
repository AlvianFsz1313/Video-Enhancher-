package com.example.videoenhancer

import android.content.Context
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class Pipeline(
    private val ctx: Context,
    private val uri: Uri,
    private val scale: Int,
    private val fps: Int,
    private val sharpen: Boolean,
    private val sr: SuperRes,
    private val onProgress: (Float, String) -> Unit,
    private val cancelled: () -> Boolean
) {
    private val maxLong = 3840

    private class Decoded(val frame: Frame, val pts: Long)

    // ---------------- Decoder ----------------
    private class Decoder(ctx: Context, uri: Uri) {
        val ex = MediaExtractor()
        val dec: MediaCodec
        val info = MediaCodec.BufferInfo()
        var eosIn = false
        var eosOut = false
        val rotation: Int
        val durationUs: Long
        val audioFormat: MediaFormat?
        val audioIndex: Int

        init {
            ex.setDataSource(ctx, uri, null)
            var v = -1; var a = -1
            for (i in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && v < 0) v = i
                if (mime.startsWith("audio/") && a < 0) a = i
            }
            require(v >= 0) { "Track video tidak ditemukan" }
            val vf = ex.getTrackFormat(v)
            rotation = if (vf.containsKey(MediaFormat.KEY_ROTATION)) vf.getInteger(MediaFormat.KEY_ROTATION) else 0
            durationUs = if (vf.containsKey(MediaFormat.KEY_DURATION)) vf.getLong(MediaFormat.KEY_DURATION) else 0L
            audioIndex = a
            audioFormat = if (a >= 0) ex.getTrackFormat(a) else null
            ex.selectTrack(v)
            vf.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            dec = MediaCodec.createDecoderByType(vf.getString(MediaFormat.KEY_MIME)!!)
            dec.configure(vf, null, null, 0)
            dec.start()
        }

        fun next(): Decoded? {
            while (!eosOut) {
                if (!eosIn) {
                    val i = dec.dequeueInputBuffer(5000)
                    if (i >= 0) {
                        val n = ex.readSampleData(dec.getInputBuffer(i)!!, 0)
                        if (n < 0) {
                            dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); eosIn = true
                        } else {
                            dec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance()
                        }
                    }
                }
                val o = dec.dequeueOutputBuffer(info, 5000)
                if (o >= 0) {
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) eosOut = true
                    var res: Decoded? = null
                    if (info.size > 0) {
                        val img: Image? = dec.getOutputImage(o)
                        if (img != null) {
                            val fr = YuvUtil.rotate(YuvUtil.toArgb(img), rotation)
                            img.close()
                            res = Decoded(fr, info.presentationTimeUs)
                        }
                    }
                    dec.releaseOutputBuffer(o, false)
                    if (res != null) return res
                }
            }
            return null
        }

        fun release() {
            try { dec.stop() } catch (_: Exception) {}
            try { dec.release() } catch (_: Exception) {}
            try { ex.release() } catch (_: Exception) {}
        }
    }

    // ---------------- Encoder ----------------
    private class Encoder(val out: File, val w: Int, val h: Int, val fps: Int, val audioFormat: MediaFormat?) {
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val codec: MediaCodec
        val info = MediaCodec.BufferInfo()
        var vTrack = -1; var aTrack = -1; var started = false
        var lastPts = 0L

        init { codec = create() }

        private fun create(): MediaCodec {
            val bitrate = min(120_000_000L, (w.toLong() * h * fps * 0.09).toLong()).toInt()
            var last: Exception? = null
            for (mime in listOf(MediaFormat.MIMETYPE_VIDEO_HEVC, MediaFormat.MIMETYPE_VIDEO_AVC)) {
                try {
                    val f = MediaFormat.createVideoFormat(mime, w, h)
                    f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
                    f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                    f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                    f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
                    f.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
                    f.setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT709)
                    f.setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
                    val c = MediaCodec.createEncoderByType(mime)
                    try {
                        c.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                        c.start()
                        return c
                    } catch (e: Exception) { c.release(); throw e }
                } catch (e: Exception) { last = e }
            }
            throw IllegalStateException("Encoder tidak mendukung ${w}x$h @${fps}fps: ${last?.message}")
        }

        fun encode(px: IntArray, ptsUs: Long) {
            while (true) {
                val i = codec.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    val img = codec.getInputImage(i)!!
                    YuvUtil.fill(img, px, w, h)
                    img.close()
                    codec.queueInputBuffer(i, 0, w * h * 3 / 2, ptsUs, 0)
                    lastPts = ptsUs
                    break
                }
                drain(false)
            }
            drain(false)
        }

        private fun drain(wait: Boolean) {
            while (true) {
                val o = codec.dequeueOutputBuffer(info, if (wait) 10_000 else 0)
                when {
                    o == MediaCodec.INFO_TRY_AGAIN_LATER -> { if (!wait) return }
                    o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        vTrack = muxer.addTrack(codec.outputFormat)
                        if (audioFormat != null) {
                            try { aTrack = muxer.addTrack(audioFormat) } catch (_: Exception) { aTrack = -1 }
                        }
                        muxer.start(); started = true
                    }
                    o >= 0 -> {
                        val buf = codec.getOutputBuffer(o)!!
                        if (info.size > 0 && started && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            buf.position(info.offset); buf.limit(info.offset + info.size)
                            muxer.writeSampleData(vTrack, buf, info)
                        }
                        val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        codec.releaseOutputBuffer(o, false)
                        if (eos) return
                    }
                }
            }
        }

        fun finish(ctx: Context, uri: Uri, audioIdx: Int) {
            while (true) {
                val i = codec.dequeueInputBuffer(10_000)
                if (i >= 0) { codec.queueInputBuffer(i, 0, 0, lastPts, MediaCodec.BUFFER_FLAG_END_OF_STREAM); break }
                drain(false)
            }
            drain(true)
            check(started) { "Encoder tidak menghasilkan output" }
            if (aTrack >= 0 && audioIdx >= 0) {
                val ex = MediaExtractor()
                try {
                    ex.setDataSource(ctx, uri, null)
                    ex.selectTrack(audioIdx)
                    val buf = ByteBuffer.allocate(1 shl 20)
                    val bi = MediaCodec.BufferInfo()
                    while (true) {
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) break
                        val fl = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                        bi.set(0, n, ex.sampleTime, fl)
                        muxer.writeSampleData(aTrack, buf, bi)
                        ex.advance()
                    }
                } finally { ex.release() }
            }
            muxer.stop()
        }

        fun release() {
            try { codec.stop() } catch (_: Exception) {}
            try { codec.release() } catch (_: Exception) {}
            try { muxer.release() } catch (_: Exception) {}
        }
    }

    // ---------------- Enhance satu frame ----------------
    private fun even(v: Float) = max(2, (v / 2f).roundToInt() * 2)

    private fun enhance(f: Frame): Frame {
        val s = min(scale.toFloat(), maxLong.toFloat() / max(f.w, f.h))
        if (scale <= 1 || s <= 1.01f) return f
        val tw = even(f.w * s); val th = even(f.h * s)
        val cur = if (sr.hasModel) sr.upscale(f, cancelled) else f
        var px = Imaging.resize(cur.px, cur.w, cur.h, tw, th)
        if (sharpen) px = Imaging.sharpen(px, tw, th, if (sr.hasModel) 0.15f else 0.35f)
        return Frame(px, tw, th)
    }

    // ---------------- Main loop (pipelined: AI di thread utama, interpolasi+encode di thread kedua) ----------------
    private class Item(val f: Frame, val t: Long)

    fun run(): File {
        val dec = Decoder(ctx, uri)
        val outFile = File(ctx.cacheDir, "enhanced_tmp.mp4")
        if (outFile.exists()) outFile.delete()
        val queue = java.util.concurrent.ArrayBlockingQueue<Any>(2)
        val end = Any()
        val errRef = java.util.concurrent.atomic.AtomicReference<Throwable?>(null)
        val encRef = java.util.concurrent.atomic.AtomicReference<Encoder?>(null)

        val worker = Thread {
            try {
                var prev: Frame? = null
                var prevT = 0L; var outIdx = 0L; var frameDur = 33_333L
                while (true) {
                    val item = queue.take()
                    if (item === end) break
                    val it2 = item as Item
                    val f = it2.f; val t = it2.t
                    var enc = encRef.get()
                    if (enc == null) { enc = Encoder(outFile, f.w, f.h, fps, dec.audioFormat); encRef.set(enc) }
                    val p = prev
                    if (p == null) { prev = f; prevT = t; continue }
                    if (t <= prevT) continue
                    frameDur = t - prevT
                    var mo: Interpolator.Motion? = null
                    while (true) {
                        val tOut = outIdx * 1_000_000L / fps
                        if (tOut >= t) break
                        val alpha = ((tOut - prevT).toFloat() / (t - prevT)).coerceIn(0f, 1f)
                        val px = when {
                            alpha < 0.03f -> p.px
                            alpha > 0.97f -> f.px
                            else -> {
                                if (mo == null) mo = Interpolator.estimate(p, f)
                                Interpolator.interpolate(p, f, mo, alpha)
                            }
                        }
                        enc.encode(px, tOut); outIdx++
                    }
                    prev = f; prevT = t
                }
                val last = prev; val enc = encRef.get()
                if (last != null && enc != null) {
                    while (true) {
                        val tOut = outIdx * 1_000_000L / fps
                        if (tOut >= prevT + frameDur) break
                        enc.encode(last.px, tOut); outIdx++
                    }
                }
                checkNotNull(encRef.get()) { "Video kosong" }.finish(ctx, uri, dec.audioIndex)
            } catch (e: Throwable) {
                errRef.set(e); queue.clear()
            }
        }

        val startNs = System.nanoTime()
        var n = 0; var t0 = -1L; var aiNs = 0L
        worker.start()
        try {
            while (true) {
                if (cancelled()) throw CancelledException()
                errRef.get()?.let { throw it }
                val d = dec.next() ?: break
                val a0 = System.nanoTime()
                val f = enhance(d.frame)
                aiNs += System.nanoTime() - a0
                if (t0 < 0) t0 = d.pts
                n++
                val item = Item(f, d.pts - t0)
                while (!queue.offer(item, 200, java.util.concurrent.TimeUnit.MILLISECONDS)) {
                    if (cancelled()) throw CancelledException()
                    errRef.get()?.let { throw it }
                }
                val pct = if (dec.durationUs > 0) ((d.pts - t0).toFloat() / dec.durationUs).coerceIn(0f, 0.99f) else 0.5f
                val el = (System.nanoTime() - startNs) / 1e9
                val eta = if (pct > 0.01f) (el / pct - el).toInt() else 0
                onProgress(pct, "Frame $n | AI %.1f dtk/frame | sisa ~%d:%02d".format(aiNs / 1e9 / n, eta / 60, eta % 60))
            }
            while (!queue.offer(end, 200, java.util.concurrent.TimeUnit.MILLISECONDS)) {
                errRef.get()?.let { throw it }
            }
            onProgress(0.99f, "Menyelesaikan encoding...")
            worker.join()
            errRef.get()?.let { throw it }
            return outFile
        } finally {
            if (worker.isAlive) { worker.interrupt(); worker.join(3000) }
            dec.release()
            encRef.get()?.release()
        }
    }
}
