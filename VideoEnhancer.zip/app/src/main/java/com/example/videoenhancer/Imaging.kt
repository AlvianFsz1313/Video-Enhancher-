package com.example.videoenhancer

import android.graphics.Bitmap
import android.media.Image
import java.util.stream.IntStream
import kotlin.math.floor
import kotlin.math.min

class Frame(val px: IntArray, val w: Int, val h: Int)

class CancelledException : RuntimeException("Dibatalkan")

object YuvUtil {
    fun toArgb(img: Image): Frame {
        val crop = img.cropRect
        val w = crop.width() and 1.inv()
        val h = crop.height() and 1.inv()
        val yP = img.planes[0]; val uP = img.planes[1]; val vP = img.planes[2]
        val yb = yP.buffer; val ub = uP.buffer; val vb = vP.buffer
        val hd = h >= 720
        val cr = if (hd) 1.793f else 1.596f
        val cgu = if (hd) 0.213f else 0.392f
        val cgv = if (hd) 0.533f else 0.813f
        val cb = if (hd) 2.112f else 2.017f
        val out = IntArray(w * h)
        IntStream.range(0, h).parallel().forEach { y ->
            val yy = y + crop.top
            for (x in 0 until w) {
                val xx = x + crop.left
                val yv = ((yb.get(yy * yP.rowStride + xx * yP.pixelStride).toInt() and 0xFF) - 16) * 1.164f
                val u = (ub.get((yy shr 1) * uP.rowStride + (xx shr 1) * uP.pixelStride).toInt() and 0xFF) - 128
                val v = (vb.get((yy shr 1) * vP.rowStride + (xx shr 1) * vP.pixelStride).toInt() and 0xFF) - 128
                val r = (yv + cr * v).toInt().coerceIn(0, 255)
                val g = (yv - cgu * u - cgv * v).toInt().coerceIn(0, 255)
                val b = (yv + cb * u).toInt().coerceIn(0, 255)
                out[y * w + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        return Frame(out, w, h)
    }

    /** Isi Image encoder (YUV420 flexible) dari ARGB. w & h harus genap. */
    fun fill(img: Image, px: IntArray, w: Int, h: Int) {
        val yP = img.planes[0]; val uP = img.planes[1]; val vP = img.planes[2]
        val yb = yP.buffer; val ub = uP.buffer; val vb = vP.buffer
        IntStream.range(0, h / 2).parallel().forEach { cy ->
            for (cx in 0 until w / 2) {
                var sr = 0; var sg = 0; var sb = 0
                for (dy in 0..1) for (dx in 0..1) {
                    val x = cx * 2 + dx; val y = cy * 2 + dy
                    val p = px[y * w + x]
                    val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
                    sr += r; sg += g; sb += b
                    val yv = (16f + 0.183f * r + 0.614f * g + 0.062f * b).toInt().coerceIn(16, 235)
                    yb.put(y * yP.rowStride + x * yP.pixelStride, yv.toByte())
                }
                val r = sr / 4f; val g = sg / 4f; val b = sb / 4f
                val u = (128f - 0.101f * r - 0.339f * g + 0.439f * b).toInt().coerceIn(16, 240)
                val v = (128f + 0.439f * r - 0.399f * g - 0.040f * b).toInt().coerceIn(16, 240)
                ub.put(cy * uP.rowStride + cx * uP.pixelStride, u.toByte())
                vb.put(cy * vP.rowStride + cx * vP.pixelStride, v.toByte())
            }
        }
    }

    fun rotate(f: Frame, deg: Int): Frame {
        return when (((deg % 360) + 360) % 360) {
            90 -> {
                val nw = f.h; val nh = f.w; val o = IntArray(f.px.size)
                for (y in 0 until f.h) for (x in 0 until f.w) o[x * nw + (f.h - 1 - y)] = f.px[y * f.w + x]
                Frame(o, nw, nh)
            }
            180 -> {
                val o = IntArray(f.px.size)
                for (i in o.indices) o[o.size - 1 - i] = f.px[i]
                Frame(o, f.w, f.h)
            }
            270 -> {
                val nw = f.h; val nh = f.w; val o = IntArray(f.px.size)
                for (y in 0 until f.h) for (x in 0 until f.w) o[(f.w - 1 - x) * nw + y] = f.px[y * f.w + x]
                Frame(o, nw, nh)
            }
            else -> f
        }
    }
}

object Imaging {
    /** Resize: bicubic (Catmull-Rom) untuk memperbesar, area/bilinear untuk memperkecil. */
    fun resize(src: IntArray, w: Int, h: Int, tw: Int, th: Int): IntArray {
        if (w == tw && h == th) return src
        if (tw < w || th < h) {
            val b = Bitmap.createBitmap(src, w, h, Bitmap.Config.ARGB_8888)
            val s = Bitmap.createScaledBitmap(b, tw, th, true)
            val o = IntArray(tw * th)
            s.getPixels(o, 0, tw, 0, 0, tw, th)
            if (s !== b) s.recycle()
            b.recycle()
            return o
        }
        val xi = IntArray(tw * 4); val xw = FloatArray(tw * 4)
        val yi = IntArray(th * 4); val yw = FloatArray(th * 4)
        weights(w, tw, xi, xw); weights(h, th, yi, yw)
        val out = IntArray(tw * th)
        IntStream.range(0, th).parallel().forEach { y ->
            for (x in 0 until tw) {
                var r = 0f; var g = 0f; var b = 0f
                for (j in 0 until 4) {
                    val row = yi[y * 4 + j] * w; val wy = yw[y * 4 + j]
                    for (i in 0 until 4) {
                        val p = src[row + xi[x * 4 + i]]
                        val k = wy * xw[x * 4 + i]
                        r += ((p shr 16) and 255) * k; g += ((p shr 8) and 255) * k; b += (p and 255) * k
                    }
                }
                out[y * tw + x] = (0xFF shl 24) or
                    ((r + 0.5f).toInt().coerceIn(0, 255) shl 16) or
                    ((g + 0.5f).toInt().coerceIn(0, 255) shl 8) or
                    (b + 0.5f).toInt().coerceIn(0, 255)
            }
        }
        return out
    }

    private fun weights(sn: Int, tn: Int, idx: IntArray, wt: FloatArray) {
        val ratio = sn.toFloat() / tn
        for (o in 0 until tn) {
            val c = (o + 0.5f) * ratio - 0.5f
            val f = floor(c).toInt(); val t = c - f
            val t2 = t * t; val t3 = t2 * t
            val k = floatArrayOf(
                -0.5f * t3 + t2 - 0.5f * t,
                1.5f * t3 - 2.5f * t2 + 1f,
                -1.5f * t3 + 2f * t2 + 0.5f * t,
                0.5f * t3 - 0.5f * t2
            )
            for (i in 0 until 4) { idx[o * 4 + i] = (f - 1 + i).coerceIn(0, sn - 1); wt[o * 4 + i] = k[i] }
        }
    }

    /** Sharpen ringan (kernel laplacian 4 arah). */
    fun sharpen(px: IntArray, w: Int, h: Int, amount: Float): IntArray {
        val out = IntArray(px.size)
        IntStream.range(0, h).parallel().forEach { y ->
            val ym = (y - 1).coerceAtLeast(0); val yp = min(y + 1, h - 1)
            for (x in 0 until w) {
                val xm = (x - 1).coerceAtLeast(0); val xp = min(x + 1, w - 1)
                val c = px[y * w + x]; val n = px[ym * w + x]; val s = px[yp * w + x]
                val e = px[y * w + xp]; val wv = px[y * w + xm]
                var res = 0xFF shl 24
                for (sh in intArrayOf(16, 8, 0)) {
                    val cc = (c shr sh) and 255
                    val lap = 4 * cc - ((n shr sh) and 255) - ((s shr sh) and 255) - ((e shr sh) and 255) - ((wv shr sh) and 255)
                    res = res or ((cc + amount * lap).toInt().coerceIn(0, 255) shl sh)
                }
                out[y * w + x] = res
            }
        }
        return out
    }
}
