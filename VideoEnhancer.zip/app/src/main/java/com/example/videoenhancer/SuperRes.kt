package com.example.videoenhancer

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import ai.onnxruntime.providers.NNAPIFlags
import android.content.Context
import android.util.Log
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.EnumSet
import kotlin.math.min

/** Super-resolution AI offline via ONNX Runtime (NNAPI = GPU/NPU/DSP -> XNNPACK -> CPU). */
class SuperRes(private val ctx: Context) {
    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private var session: OrtSession? = null
    private var inputName = ""
    private var tileIn = 128
    var modelScale = 1; private set
    var backend = "fallback"; private set
    val hasModel get() = session != null

    companion object { const val PAD = 10 }

    fun loadFromApp(): String {
        val f = File(ctx.filesDir, "sr.onnx")
        val bytes: ByteArray? = if (f.exists()) f.readBytes() else try {
            ctx.assets.open("models/sr.onnx").use { it.readBytes() }
        } catch (e: Exception) { null }
        if (bytes == null) return "Model AI tidak ada -> mode fallback (Bicubic + Sharpen)"
        val cores = Runtime.getRuntime().availableProcessors()
        for (mode in listOf("nnapi", "xnnpack", "cpu")) {
            try {
                val opts = OrtSession.SessionOptions()
                opts.setIntraOpNumThreads(if (mode == "xnnpack") 1 else cores)
                opts.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
                when (mode) {
                    "nnapi" -> opts.addNnapi(EnumSet.of(NNAPIFlags.USE_FP16))
                    "xnnpack" -> opts.addXnnpack(mapOf("intra_op_num_threads" to cores.toString()))
                }
                val s = env.createSession(bytes, opts)
                val name = s.inputNames.first()
                val shape = (s.inputInfo[name]!!.info as TensorInfo).shape
                if (shape.size == 4 && shape[2] > 0) tileIn = shape[2].toInt()
                val sc = probe(s, name)
                session = s; inputName = name; modelScale = sc; backend = mode
                return "Model AI aktif: backend=$mode, skala bawaan model x$sc"
            } catch (e: Throwable) {
                Log.w("SuperRes", "backend $mode gagal: ${e.message}")
            }
        }
        return "Model gagal dimuat -> mode fallback (cek format model: NCHW float32 RGB 0..1)"
    }

    private fun probe(s: OrtSession, name: String): Int {
        val t = tileIn
        val buf = ByteBuffer.allocateDirect(3 * t * t * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        OnnxTensor.createTensor(env, buf, longArrayOf(1, 3, t.toLong(), t.toLong())).use { tensor ->
            s.run(mapOf(name to tensor)).use { r ->
                val shp = (r[0] as OnnxTensor).info.shape
                require(shp.size == 4 && shp[1] == 3L) { "Output model tidak valid" }
                return (shp[3] / t).toInt().also { require(it >= 1) { "Skala model tidak valid" } }
            }
        }
    }

    fun upscale(f: Frame, cancelled: () -> Boolean): Frame {
        val s = session!!; val m = modelScale; val t = tileIn; val core = t - 2 * PAD
        val ow = f.w * m; val oh = f.h * m
        if (ow.toLong() * oh > 40_000_000L)
            throw IllegalStateException("Resolusi terlalu besar untuk AI x$m. Pakai video lebih kecil atau skala 2x.")
        val out = IntArray(ow * oh)
        val inBuf = ByteBuffer.allocateDirect(3 * t * t * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        val shape = longArrayOf(1, 3, t.toLong(), t.toLong())
        val plane = t * t
        val ot = t * m
        var ty = 0
        while (ty < f.h) {
            var tx = 0
            while (tx < f.w) {
                if (cancelled()) throw CancelledException()
                for (yy in 0 until t) {
                    val row = (ty - PAD + yy).coerceIn(0, f.h - 1) * f.w
                    for (xx in 0 until t) {
                        val p = f.px[row + (tx - PAD + xx).coerceIn(0, f.w - 1)]
                        val i = yy * t + xx
                        inBuf.put(i, ((p shr 16) and 255) / 255f)
                        inBuf.put(plane + i, ((p shr 8) and 255) / 255f)
                        inBuf.put(2 * plane + i, (p and 255) / 255f)
                    }
                }
                inBuf.rewind()
                OnnxTensor.createTensor(env, inBuf, shape).use { tensor ->
                    s.run(mapOf(inputName to tensor)).use { r ->
                        val o = (r[0] as OnnxTensor).floatBuffer
                        val oplane = ot * ot
                        val cw = min(core, f.w - tx); val ch = min(core, f.h - ty)
                        for (yy in 0 until ch * m) {
                            val oy = ty * m + yy
                            for (xx in 0 until cw * m) {
                                val si = (PAD * m + yy) * ot + (PAD * m + xx)
                                val rr = (o.get(si).coerceIn(0f, 1f) * 255f + 0.5f).toInt()
                                val gg = (o.get(oplane + si).coerceIn(0f, 1f) * 255f + 0.5f).toInt()
                                val bb = (o.get(2 * oplane + si).coerceIn(0f, 1f) * 255f + 0.5f).toInt()
                                out[oy * ow + tx * m + xx] = (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
                            }
                        }
                    }
                }
                tx += core
            }
            ty += core
        }
        return Frame(out, ow, oh)
    }
}
