package com.example.videoenhancer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.IBinder
import android.os.PowerManager
import android.provider.MediaStore
import androidx.core.app.NotificationCompat

object ProgressHub {
    @Volatile var listener: ((Float, String, Boolean) -> Unit)? = null
    @Volatile var lastPct = 0f
    @Volatile var lastMsg = ""
    @Volatile var running = false
    fun update(p: Float, msg: String) { lastPct = p; lastMsg = msg; running = true; listener?.invoke(p, msg, false) }
    fun done(msg: String) { running = false; lastPct = 1f; lastMsg = msg; listener?.invoke(1f, msg, true) }
}

class EnhanceService : Service() {
    companion object { const val ACTION_CANCEL = "cancel" }

    @Volatile private var cancel = false
    private var thread: Thread? = null
    private var lastNotify = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) { cancel = true; return START_NOT_STICKY }
        if (thread?.isAlive == true || intent == null) return START_NOT_STICKY
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("enh", "Proses video", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, notif(0f, "Memulai..."), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        val uri = Uri.parse(intent.getStringExtra("uri"))
        val scale = intent.getIntExtra("scale", 2)
        val fps = intent.getIntExtra("fps", 90)
        val sharpen = intent.getBooleanExtra("sharpen", true)
        cancel = false
        thread = Thread { work(uri, scale, fps, sharpen) }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun notif(p: Float, msg: String): Notification =
        NotificationCompat.Builder(this, "enh")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Video Enhancer")
            .setContentText(msg)
            .setProgress(100, (p * 100).toInt(), false)
            .setOngoing(true).build()

    private fun work(uri: Uri, scale: Int, fps: Int, sharpen: Boolean) {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "videoenhancer:work")
        wl.acquire(6 * 60 * 60 * 1000L)
        try {
            ProgressHub.update(0f, "Memuat model AI...")
            val sr = SuperRes(this)
            ProgressHub.update(0f, sr.loadFromApp())
            val file = Pipeline(this, uri, scale, fps, sharpen, sr,
                { p, m ->
                    ProgressHub.update(p, m)
                    val now = System.currentTimeMillis()
                    if (now - lastNotify > 1500) {
                        lastNotify = now
                        getSystemService(NotificationManager::class.java).notify(1, notif(p, m))
                    }
                }, { cancel }).run()
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "enhanced_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VideoEnhancer")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val out = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)!!
            contentResolver.openOutputStream(out)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
            v.clear(); v.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(out, v, null, null)
            file.delete()
            ProgressHub.done("Selesai! Tersimpan di Movies/VideoEnhancer")
        } catch (e: CancelledException) {
            ProgressHub.done("Dibatalkan")
        } catch (e: Throwable) {
            ProgressHub.done("Gagal: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            if (wl.isHeld) wl.release()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }
}
