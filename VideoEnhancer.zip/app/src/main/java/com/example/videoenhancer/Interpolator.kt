package com.example.videoenhancer

import java.util.stream.IntStream
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** Interpolasi frame berbasis motion-compensation (block matching + warp dua arah + penanganan oklusi). */
object Interpolator {
    class Motion(val bx: Int, val by: Int, val blkFull: Float, val vx: FloatArray, val vy: FloatArray)

    private const val B = 8
    private const val R = 16

    private fun small(fr: Frame, f: Int, sw: Int, sh: Int): IntArray {
        val o = IntArray(sw * sh)
        IntStream.range(0, sh).parallel().forEach { y ->
            for (x in 0 until sw) {
                var s = 0
                for (dy in 0 until f) for (dx in 0 until f) {
                    val p = fr.px[min(y * f + dy, fr.h - 1) * fr.w + min(x * f + dx, fr.w - 1)]
                    s += (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8
                }
                o[y * sw + x] = s / (f * f)
            }
        }
        return o
    }

    private fun sad(a: IntArray, b: IntArray, sw: Int, sh: Int, x0: Int, y0: Int, bw: Int, bh: Int, dx: Int, dy: Int, bestSoFar: Int): Int {
        var s = 2 * (abs(dx) + abs(dy))
        for (y in 0 until bh) {
            val sy = (y0 + y + dy).coerceIn(0, sh - 1)
            for (x in 0 until bw) {
                val sx = (x0 + x + dx).coerceIn(0, sw - 1)
                s += abs(a[(y0 + y) * sw + x0 + x] - b[sy * sw + sx])
            }
            if (s >= bestSoFar) return s
        }
        return s
    }

    fun estimate(a: Frame, b: Frame): Motion {
        val f = max(1, a.w / 384)
        val sw = a.w / f; val sh = a.h / f
        val la = small(a, f, sw, sh); val lb = small(b, f, sw, sh)
        val bx = (sw + B - 1) / B; val by = (sh + B - 1) / B
        val vx = FloatArray(bx * by); val vy = FloatArray(bx * by)
        IntStream.range(0, bx * by).parallel().forEach { i ->
            val x0 = (i % bx) * B; val y0 = (i / bx) * B
            val bw = min(B, sw - x0); val bh = min(B, sh - y0)
            var best = Int.MAX_VALUE; var bdx = 0; var bdy = 0
            var dy = -R
            while (dy <= R) {
                var dx = -R
                while (dx <= R) {
                    val c = sad(la, lb, sw, sh, x0, y0, bw, bh, dx, dy, best)
                    if (c < best) { best = c; bdx = dx; bdy = dy }
                    dx += 2
                }
                dy += 2
            }
            val cx = bdx; val cy = bdy
            for (ddy in cy - 1..cy + 1) for (ddx in cx - 1..cx + 1) {
                val c = sad(la, lb, sw, sh, x0, y0, bw, bh, ddx, ddy, best)
                if (c < best) { best = c; bdx = ddx; bdy = ddy }
            }
            vx[i] = bdx * f.toFloat(); vy[i] = bdy * f.toFloat()
        }
        return Motion(bx, by, (B * f).toFloat(), median3(vx, bx, by), median3(vy, bx, by))
    }

    private fun median3(v: FloatArray, bx: Int, by: Int): FloatArray {
        val o = FloatArray(v.size)
        val t = FloatArray(9)
        for (y in 0 until by) for (x in 0 until bx) {
            var n = 0
            for (dy in -1..1) for (dx in -1..1) {
                t[n++] = v[(y + dy).coerceIn(0, by - 1) * bx + (x + dx).coerceIn(0, bx - 1)]
            }
            java.util.Arrays.sort(t)
            o[y * bx + x] = t[4]
        }
        return o
    }

    private fun bl(c00: Int, c10: Int, c01: Int, c11: Int, fx: Int, fy: Int): Int {
        val top = c00 * (256 - fx) + c10 * fx
        val bot = c01 * (256 - fx) + c11 * fx
        return (top * (256 - fy) + bot * fy) shr 16
    }

    private fun sample(px: IntArray, w: Int, h: Int, x: Float, y: Float): Int {
        val xc = x.coerceIn(0f, (w - 1).toFloat()); val yc = y.coerceIn(0f, (h - 1).toFloat())
        val x0 = xc.toInt(); val y0 = yc.toInt()
        val x1 = min(x0 + 1, w - 1); val y1 = min(y0 + 1, h - 1)
        val fx = ((xc - x0) * 256).toInt(); val fy = ((yc - y0) * 256).toInt()
        val p00 = px[y0 * w + x0]; val p10 = px[y0 * w + x1]; val p01 = px[y1 * w + x0]; val p11 = px[y1 * w + x1]
        val r = bl((p00 shr 16) and 255, (p10 shr 16) and 255, (p01 shr 16) and 255, (p11 shr 16) and 255, fx, fy)
        val g = bl((p00 shr 8) and 255, (p10 shr 8) and 255, (p01 shr 8) and 255, (p11 shr 8) and 255, fx, fy)
        val b = bl(p00 and 255, p10 and 255, p01 and 255, p11 and 255, fx, fy)
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    private fun mix(p: Int, q: Int, t256: Int): Int {
        val r = (((p shr 16) and 255) * (256 - t256) + ((q shr 16) and 255) * t256) shr 8
        val g = (((p shr 8) and 255) * (256 - t256) + ((q shr 8) and 255) * t256) shr 8
        val b = ((p and 255) * (256 - t256) + (q and 255) * t256) shr 8
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    fun interpolate(a: Frame, b: Frame, m: Motion, alpha: Float): IntArray {
        val w = a.w; val h = a.h
        val out = IntArray(w * h)
        val a256 = (alpha * 256).toInt()
        IntStream.range(0, h).parallel().forEach { y ->
            val fy = (y + 0.5f) / m.blkFull - 0.5f
            val y0 = floor(fy).toInt(); val ty = fy - y0
            val iy0 = y0.coerceIn(0, m.by - 1); val iy1 = (y0 + 1).coerceIn(0, m.by - 1)
            for (x in 0 until w) {
                val fx = (x + 0.5f) / m.blkFull - 0.5f
                val x0 = floor(fx).toInt(); val tx = fx - x0
                val ix0 = x0.coerceIn(0, m.bx - 1); val ix1 = (x0 + 1).coerceIn(0, m.bx - 1)
                val vx = lerp(lerp(m.vx[iy0 * m.bx + ix0], m.vx[iy0 * m.bx + ix1], tx),
                    lerp(m.vx[iy1 * m.bx + ix0], m.vx[iy1 * m.bx + ix1], tx), ty)
                val vy = lerp(lerp(m.vy[iy0 * m.bx + ix0], m.vy[iy0 * m.bx + ix1], tx),
                    lerp(m.vy[iy1 * m.bx + ix0], m.vy[iy1 * m.bx + ix1], tx), ty)
                val pa = sample(a.px, w, h, x - alpha * vx, y - alpha * vy)
                val pb = sample(b.px, w, h, x + (1 - alpha) * vx, y + (1 - alpha) * vy)
                val diff = abs(((pa shr 16) and 255) - ((pb shr 16) and 255)) +
                    abs(((pa shr 8) and 255) - ((pb shr 8) and 255)) +
                    abs((pa and 255) - (pb and 255))
                val warp = mix(pa, pb, a256)
                val wgt = ((diff - 48) / 96f).coerceIn(0f, 1f)
                out[y * w + x] = if (wgt <= 0f) warp else {
                    val near = if (alpha < 0.5f) a.px[y * w + x] else b.px[y * w + x]
                    mix(warp, near, (wgt * 256).toInt())
                }
            }
        }
        return out
    }
}
